import { useEffect, useMemo, useState } from "react";
import {
  Activity,
  CandlestickChart,
  Layers3,
  Loader2,
  RefreshCw,
  Search,
  Wifi
} from "lucide-react";
import BacktestPanel from "./components/BacktestPanel";
import ChatPanel from "./components/ChatPanel";
import MetricStrip from "./components/MetricStrip";
import PriceChart from "./components/PriceChart";
import SignalPanel from "./components/SignalPanel";
import TradingViewWidget from "./components/TradingViewWidget";
import { api } from "./services/api";
import { actionClass, formatPrice } from "./lib/format";

const TIMEFRAMES = ["1m", "5m", "15m", "1h", "4h", "1d"];
const WATCHLIST = [
  { symbol: "BTC/USDT", assetType: "crypto" },
  { symbol: "ETH/USDT", assetType: "crypto" },
  { symbol: "SOL/USDT", assetType: "crypto" },
  { symbol: "AAPL", assetType: "stock" },
  { symbol: "TSLA", assetType: "stock" },
  { symbol: "QQQ", assetType: "stock" }
];

export default function App() {
  const [symbol, setSymbol] = useState("BTC/USDT");
  const [assetType, setAssetType] = useState("crypto");
  const [timeframe, setTimeframe] = useState("15m");
  const [analysis, setAnalysis] = useState(null);
  const [signals, setSignals] = useState([]);
  const [metrics, setMetrics] = useState(null);
  const [backtest, setBacktest] = useState(null);
  const [liveQuote, setLiveQuote] = useState(null);
  const [loading, setLoading] = useState({ analyze: false, chat: false, signals: false, backtest: false });
  const [error, setError] = useState("");
  const [messages, setMessages] = useState([
    {
      role: "assistant",
      content: "Ready. Try BTC/USDT, ETH/USDT, QQQ, AAPL, or TSLA."
    }
  ]);

  const selectedWatch = useMemo(
    () => WATCHLIST.find((item) => item.symbol === symbol) || { symbol, assetType },
    [symbol, assetType]
  );

  useEffect(() => {
    loadInitial();
  }, []);

  useEffect(() => {
    const encoded = encodeURIComponent(symbol);
    const socket = new WebSocket(api.wsUrl(`/api/ws/market?symbol=${encoded}&asset_type=${assetType}&timeframe=1m`));
    socket.onmessage = (event) => {
      try {
        setLiveQuote(JSON.parse(event.data));
      } catch {
        setLiveQuote(null);
      }
    };
    socket.onerror = () => socket.close();
    return () => socket.close();
  }, [symbol, assetType]);

  async function loadInitial() {
    await Promise.allSettled([runAnalyze(), loadSignals(), loadMetrics()]);
  }

  async function runAnalyze(overrides = {}) {
    setLoading((state) => ({ ...state, analyze: true }));
    setError("");
    try {
      const payload = {
        symbol: overrides.symbol || symbol,
        asset_type: overrides.assetType || assetType,
        timeframe: overrides.timeframe || timeframe,
        limit: 260
      };
      const result = await api.analyze(payload);
      setAnalysis(result);
      if (overrides.symbol) setSymbol(overrides.symbol);
      if (overrides.assetType) setAssetType(overrides.assetType);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading((state) => ({ ...state, analyze: false }));
    }
  }

  async function loadSignals() {
    setLoading((state) => ({ ...state, signals: true }));
    try {
      setSignals(await api.signals(10));
    } catch {
      setSignals([]);
    } finally {
      setLoading((state) => ({ ...state, signals: false }));
    }
  }

  async function refreshSignals() {
    setLoading((state) => ({ ...state, signals: true }));
    setError("");
    try {
      await api.refreshSignals();
      await loadSignals();
      await loadMetrics();
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading((state) => ({ ...state, signals: false }));
    }
  }

  async function loadMetrics() {
    try {
      setMetrics(await api.metrics());
    } catch {
      setMetrics(null);
    }
  }

  async function sendChat(content) {
    setMessages((items) => [...items, { role: "user", content }]);
    setLoading((state) => ({ ...state, chat: true }));
    setError("");
    try {
      const response = await api.chat({ message: content, symbol, asset_type: assetType, timeframe });
      setAnalysis(response.analysis);
      setMessages((items) => [...items, { role: "assistant", content: response.answer }]);
      await Promise.allSettled([loadSignals(), loadMetrics()]);
    } catch (err) {
      setError(err.message);
      setMessages((items) => [...items, { role: "assistant", content: `I could not complete that request: ${err.message}` }]);
    } finally {
      setLoading((state) => ({ ...state, chat: false }));
    }
  }

  async function runBacktest() {
    setLoading((state) => ({ ...state, backtest: true }));
    setError("");
    try {
      const result = await api.backtest({
        symbol,
        asset_type: assetType,
        timeframe,
        limit: 650,
        account_equity: 10000,
        risk_percent: 0.01
      });
      setBacktest(result);
      await loadMetrics();
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading((state) => ({ ...state, backtest: false }));
    }
  }

  function selectWatch(item) {
    setSymbol(item.symbol);
    setAssetType(item.assetType);
    runAnalyze({ symbol: item.symbol, assetType: item.assetType });
  }

  return (
    <main className="min-h-screen px-4 py-4 md:px-6 xl:px-8">
      <div className="mx-auto flex max-w-[1800px] flex-col gap-4">
        <header className="flex flex-col gap-3 rounded-lg border border-line bg-panel/95 px-4 py-3 shadow-glow lg:flex-row lg:items-center lg:justify-between">
          <div className="flex items-center gap-3">
            <div className="flex h-11 w-11 items-center justify-center rounded-lg bg-teal-300 text-ink">
              <CandlestickChart size={23} />
            </div>
            <div>
              <h1 className="text-xl font-semibold text-white">AI Trading Desk</h1>
              <div className="mt-1 flex flex-wrap items-center gap-2 text-xs text-mist">
                <span className="inline-flex items-center gap-1"><Wifi size={13} /> {symbol}</span>
                <span>{timeframe}</span>
                <span>{assetType}</span>
              </div>
            </div>
          </div>

          <div className="flex flex-col gap-2 sm:flex-row sm:items-center">
            <div className="flex min-w-0 rounded-md border border-line bg-ink p-1">
              {["crypto", "stock"].map((type) => (
                <button
                  key={type}
                  type="button"
                  onClick={() => setAssetType(type)}
                  className={`rounded px-3 py-1.5 text-sm capitalize transition ${
                    assetType === type ? "bg-teal-300 text-ink" : "text-mist hover:text-slate-100"
                  }`}
                >
                  {type}
                </button>
              ))}
            </div>

            <div className="relative">
              <Search size={16} className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-mist" />
              <input
                value={symbol}
                onChange={(event) => setSymbol(event.target.value.toUpperCase())}
                className="h-10 w-full rounded-md border border-line bg-ink pl-9 pr-3 text-sm text-slate-100 outline-none transition focus:border-teal-400 sm:w-36"
              />
            </div>

            <select
              value={timeframe}
              onChange={(event) => setTimeframe(event.target.value)}
              className="h-10 rounded-md border border-line bg-ink px-3 text-sm text-slate-100 outline-none transition focus:border-teal-400"
            >
              {TIMEFRAMES.map((item) => (
                <option key={item}>{item}</option>
              ))}
            </select>

            <button
              type="button"
              onClick={() => runAnalyze()}
              disabled={loading.analyze}
              className="inline-flex h-10 items-center justify-center gap-2 rounded-md bg-teal-300 px-4 text-sm font-semibold text-ink transition hover:bg-teal-200 disabled:cursor-not-allowed disabled:opacity-50"
            >
              {loading.analyze ? <Loader2 size={16} className="animate-spin" /> : <RefreshCw size={16} />}
              Analyze
            </button>
          </div>
        </header>

        {error && (
          <div className="rounded-lg border border-rose-400/30 bg-rose-500/10 px-4 py-3 text-sm text-rose-100">
            {error}
          </div>
        )}

        <MetricStrip analysis={analysis} metrics={metrics} />

        <div className="grid gap-4 xl:grid-cols-[280px_minmax(0,1fr)_420px]">
          <aside className="rounded-lg border border-line bg-panel p-4 shadow-glow">
            <div className="mb-3 flex items-center gap-2">
              <Layers3 size={18} className="text-teal-300" />
              <h2 className="text-sm font-semibold uppercase tracking-wide text-slate-200">Watchlist</h2>
            </div>
            <div className="space-y-2">
              {WATCHLIST.map((item) => (
                <button
                  key={item.symbol}
                  type="button"
                  onClick={() => selectWatch(item)}
                  className={`flex w-full items-center justify-between rounded-md border px-3 py-2 text-left transition ${
                    selectedWatch.symbol === item.symbol
                      ? "border-teal-300 bg-teal-300/10 text-teal-100"
                      : "border-line bg-ink/40 text-slate-200 hover:border-slate-500"
                  }`}
                >
                  <span className="font-medium">{item.symbol}</span>
                  <span className="text-xs uppercase text-mist">{item.assetType}</span>
                </button>
              ))}
            </div>

            <div className="mt-4 rounded-lg border border-line bg-ink/40 p-3">
              <div className="flex items-center justify-between text-xs text-mist">
                <span>Live Quote</span>
                <Activity size={14} className="text-teal-300" />
              </div>
              <div className="mt-2 truncate text-2xl font-semibold text-white">
                {liveQuote ? formatPrice(liveQuote.price) : formatPrice(analysis?.entry)}
              </div>
              <div className="mt-1 text-xs text-mist">{liveQuote?.timestamp ? new Date(liveQuote.timestamp).toLocaleString() : "Waiting"}</div>
            </div>

            {analysis && (
              <div className="mt-4 rounded-lg border border-line bg-ink/40 p-3">
                <div className="flex items-center justify-between">
                  <span className={`rounded-md border px-2 py-1 text-xs font-semibold ${actionClass(analysis.action)}`}>
                    {analysis.action.toUpperCase()}
                  </span>
                  <span className="text-xs text-mist">{analysis.timeframe}</span>
                </div>
                <div className="mt-3 grid grid-cols-2 gap-2 text-xs">
                  <div>
                    <div className="text-mist">RSI</div>
                    <div className="font-semibold text-slate-100">{analysis.indicators.rsi_14?.toFixed?.(1) ?? "-"}</div>
                  </div>
                  <div>
                    <div className="text-mist">MACD</div>
                    <div className="font-semibold text-slate-100">{analysis.indicators.macd_hist?.toFixed?.(4) ?? "-"}</div>
                  </div>
                  <div>
                    <div className="text-mist">BOS</div>
                    <div className="font-semibold capitalize text-slate-100">{analysis.ict.bos.direction}</div>
                  </div>
                  <div>
                    <div className="text-mist">FVG</div>
                    <div className="font-semibold capitalize text-slate-100">{analysis.ict.fvg.latest?.direction || "none"}</div>
                  </div>
                </div>
              </div>
            )}
          </aside>

          <section className="flex flex-col gap-4">
            <TradingViewWidget symbol={symbol} assetType={assetType} timeframe={timeframe} />
            <PriceChart candles={analysis?.candles || []} />
            <BacktestPanel result={backtest || metrics?.latest_backtest} loading={loading.backtest} onRun={runBacktest} />
          </section>

          <div className="flex flex-col gap-4">
            <ChatPanel messages={messages} loading={loading.chat} onSubmit={sendChat} />
            <SignalPanel
              analysis={analysis}
              signals={signals}
              loading={loading.signals}
              onRefresh={refreshSignals}
            />
          </div>
        </div>
      </div>
    </main>
  );
}
