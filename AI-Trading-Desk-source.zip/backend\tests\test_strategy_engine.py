import pandas as pd

from strategies import StrategyEngine


def test_strategy_engine_returns_signal_payload():
    rows = []
    price = 100.0
    for index in range(240):
        price += 0.12
        rows.append(
            {
                "timestamp": pd.Timestamp("2026-01-01", tz="UTC") + pd.Timedelta(minutes=index * 15),
                "open": price - 0.4,
                "high": price + 0.8,
                "low": price - 0.7,
                "close": price,
                "volume": 1000 + index,
            }
        )

    signal = StrategyEngine().analyze(pd.DataFrame(rows), "TEST/USDT", "crypto", "15m")
    assert signal["symbol"] == "TEST/USDT"
    assert signal["action"] in {"buy", "sell", "hold"}
    assert "risk" in signal
    assert signal["risk_reward"] >= 0
