from __future__ import annotations

from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

import pandas as pd

from backend.app.config import get_settings
from strategies.ict import analyze_ict
from strategies.indicators import add_indicators, latest_indicator_snapshot


class StrategyEngine:
    """Combines indicators, ICT-inspired concepts, and risk rules into a trade signal."""

    def __init__(self) -> None:
        self.settings = get_settings()

    def analyze(
        self,
        raw_df: pd.DataFrame,
        symbol: str,
        asset_type: str,
        timeframe: str,
        account_equity: Optional[float] = None,
        risk_percent: Optional[float] = None,
    ) -> Dict[str, Any]:
        df = add_indicators(raw_df)
        if len(df) < 60:
            raise ValueError("At least 60 candles are required for analysis.")

        df = df.dropna(subset=["ema_20", "ema_50", "rsi_14", "macd_hist", "atr_14"])
        if df.empty:
            raise ValueError("Not enough complete indicator data for analysis.")

        ict = analyze_ict(df)
        row = df.iloc[-1]
        previous = df.iloc[-2]
        entry = float(row["close"])
        atr_value = max(float(row["atr_14"]), entry * 0.002)
        account_equity = account_equity or self.settings.account_equity
        risk_percent = risk_percent or self.settings.max_risk_per_trade

        buy_score, sell_score, reasons = self._score(row, previous, ict)
        action = "buy" if buy_score >= sell_score else "sell"
        confidence = max(buy_score, sell_score)

        if confidence < 0.52:
            action = "hold"

        stop_loss, take_profit, risk_reward = self._levels(action, entry, atr_value, df, ict)
        position_size = self._position_size(
            action=action,
            entry=entry,
            stop_loss=stop_loss,
            equity=account_equity,
            risk_percent=risk_percent,
        )

        indicators = latest_indicator_snapshot(df)
        rationale = self._rationale(action, confidence, reasons, indicators, ict)
        candles = self._serialize_candles(df.tail(160))

        return {
            "symbol": symbol.upper(),
            "asset_type": asset_type,
            "timeframe": timeframe,
            "action": action,
            "confidence": round(float(confidence), 3),
            "entry": round(entry, 6),
            "stop_loss": round(float(stop_loss), 6),
            "take_profit": round(float(take_profit), 6),
            "risk_reward": round(float(risk_reward), 2),
            "position_size": round(float(position_size), 6),
            "rationale": rationale,
            "indicators": indicators,
            "ict": ict,
            "risk": {
                "account_equity": round(float(account_equity), 2),
                "risk_percent": round(float(risk_percent), 4),
                "risk_amount": round(float(account_equity * risk_percent), 2),
                "minimum_rr": self.settings.minimum_rr,
                "daily_loss_limit": round(float(account_equity * self.settings.max_daily_loss), 2),
            },
            "candles": candles,
            "timestamp": datetime.now(timezone.utc),
        }

    def _score(self, row: pd.Series, previous: pd.Series, ict: Dict[str, Any]):
        buy = 0.0
        sell = 0.0
        reasons: List[str] = []

        close = float(row["close"])
        ema_20 = float(row["ema_20"])
        ema_50 = float(row["ema_50"])
        ema_200 = float(row.get("ema_200", ema_50) or ema_50)
        rsi_value = float(row["rsi_14"])
        macd_hist = float(row["macd_hist"])
        prev_macd_hist = float(previous["macd_hist"])
        volume_ratio = float(row.get("volume_ratio", 1.0) or 1.0)

        if close > ema_20 > ema_50:
            buy += 0.22
            reasons.append("price is above the 20/50 EMA trend stack")
        if close < ema_20 < ema_50:
            sell += 0.22
            reasons.append("price is below the 20/50 EMA trend stack")

        if ema_50 > ema_200:
            buy += 0.08
        elif ema_50 < ema_200:
            sell += 0.08

        if 50 <= rsi_value <= 68:
            buy += 0.16
            reasons.append(f"RSI is constructive at {rsi_value:.1f}")
        elif 32 <= rsi_value <= 50:
            sell += 0.16
            reasons.append(f"RSI is weak at {rsi_value:.1f}")
        elif rsi_value < 30:
            buy += 0.08
            reasons.append("RSI is oversold, favoring mean-reversion caution")
        elif rsi_value > 70:
            sell += 0.08
            reasons.append("RSI is overbought, favoring pullback caution")

        if macd_hist > 0 and macd_hist >= prev_macd_hist:
            buy += 0.16
            reasons.append("MACD histogram is positive and improving")
        elif macd_hist < 0 and macd_hist <= prev_macd_hist:
            sell += 0.16
            reasons.append("MACD histogram is negative and deteriorating")

        bos = ict["bos"]
        if bos["direction"] == "bullish":
            buy += 0.18 + 0.08 * bos["strength"]
            reasons.append(f"bullish break of structure above {bos['level']}")
        elif bos["direction"] == "bearish":
            sell += 0.18 + 0.08 * bos["strength"]
            reasons.append(f"bearish break of structure below {bos['level']}")

        latest_fvg = ict["fvg"]["latest"]
        if latest_fvg and latest_fvg["direction"] == "bullish":
            buy += 0.10
            reasons.append("recent bullish fair value gap shows upside imbalance")
        elif latest_fvg and latest_fvg["direction"] == "bearish":
            sell += 0.10
            reasons.append("recent bearish fair value gap shows downside imbalance")

        if volume_ratio >= 1.2:
            if buy >= sell:
                buy += 0.08
            else:
                sell += 0.08
            reasons.append(f"volume is {volume_ratio:.2f}x its 20-period average")

        # Keep scores in a probability-like range without pretending they are calibrated odds.
        buy = min(0.94, 0.30 + buy)
        sell = min(0.94, 0.30 + sell)
        return buy, sell, reasons

    def _levels(
        self, action: str, entry: float, atr_value: float, df: pd.DataFrame, ict: Dict[str, Any]
    ):
        recent_low = float(df.tail(30)["low"].min())
        recent_high = float(df.tail(30)["high"].max())
        rr = self.settings.minimum_rr

        if action == "buy":
            liquidity_stop = ict["liquidity"].get("nearest_sell_liquidity") or recent_low
            stop_loss = min(entry - atr_value * 1.25, float(liquidity_stop) - atr_value * 0.10)
            risk = max(entry - stop_loss, atr_value)
            take_profit = entry + risk * rr
            return stop_loss, take_profit, rr

        if action == "sell":
            liquidity_stop = ict["liquidity"].get("nearest_buy_liquidity") or recent_high
            stop_loss = max(entry + atr_value * 1.25, float(liquidity_stop) + atr_value * 0.10)
            risk = max(stop_loss - entry, atr_value)
            take_profit = entry - risk * rr
            return stop_loss, take_profit, rr

        stop_loss = entry - atr_value
        take_profit = entry + atr_value * rr
        return stop_loss, take_profit, 0.0

    def _position_size(
        self, action: str, entry: float, stop_loss: float, equity: float, risk_percent: float
    ) -> float:
        if action == "hold":
            return 0.0
        risk_per_unit = abs(entry - stop_loss)
        if risk_per_unit <= 0:
            return 0.0
        return (equity * risk_percent) / risk_per_unit

    def _rationale(
        self,
        action: str,
        confidence: float,
        reasons: List[str],
        indicators: Dict[str, Any],
        ict: Dict[str, Any],
    ) -> str:
        if action == "hold":
            return (
                "No trade is preferred because the signal stack is mixed. "
                "Wait for cleaner structure, momentum, and volume alignment."
            )

        direction = "long" if action == "buy" else "short"
        confidence_text = f"{confidence * 100:.0f}%"
        core = "; ".join(reasons[:5]) if reasons else "technical factors are aligned"
        bos = ict["bos"]["direction"]
        fvg = ict["fvg"]["latest"]["direction"] if ict["fvg"]["latest"] else "none"
        return (
            f"Candidate {direction} setup with {confidence_text} model confidence. "
            f"Reasoning: {core}. ICT context: BOS={bos}, latest FVG={fvg}. "
            f"Indicator snapshot: RSI {indicators.get('rsi_14', 0):.1f}, "
            f"MACD histogram {indicators.get('macd_hist', 0):.4f}. "
            "This is a probabilistic setup, not financial advice."
        )

    def _serialize_candles(self, df: pd.DataFrame) -> List[Dict[str, Any]]:
        candles: List[Dict[str, Any]] = []
        for _, row in df.iterrows():
            candles.append(
                {
                    "time": row["timestamp"].isoformat(),
                    "open": round(float(row["open"]), 6),
                    "high": round(float(row["high"]), 6),
                    "low": round(float(row["low"]), 6),
                    "close": round(float(row["close"]), 6),
                    "volume": round(float(row["volume"]), 6),
                }
            )
        return candles
