import {
  BarElement,
  CategoryScale,
  Chart as ChartJS,
  LinearScale,
  Tooltip
} from "chart.js";
import { BarChart3, Loader2, Play } from "lucide-react";
import { Bar } from "react-chartjs-2";
import { formatPrice, percent } from "../lib/format";

ChartJS.register(CategoryScale, LinearScale, BarElement, Tooltip);

export default function BacktestPanel({ result, loading, onRun }) {
  const chartData = {
    labels: result?.equity_curve?.slice(-40).map((point) => new Date(point.time).toLocaleDateString()) || [],
    datasets: [
      {
        label: "Equity",
        data: result?.equity_curve?.slice(-40).map((point) => point.equity) || [],
        backgroundColor: "rgba(245, 158, 11, 0.72)",
        borderRadius: 4
      }
    ]
  };

  return (
    <section className="rounded-lg border border-line bg-panel p-4 shadow-glow">
      <div className="mb-4 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <BarChart3 size={18} className="text-amber-300" />
          <h2 className="text-sm font-semibold uppercase tracking-wide text-slate-200">Backtest</h2>
        </div>
        <button
          type="button"
          title="Run backtest"
          onClick={onRun}
          disabled={loading}
          className="inline-flex h-9 items-center gap-2 rounded-md bg-amber-300 px-3 text-sm font-semibold text-ink transition hover:bg-amber-200 disabled:cursor-not-allowed disabled:opacity-50"
        >
          {loading ? <Loader2 size={16} className="animate-spin" /> : <Play size={16} />} Run
        </button>
      </div>

      <div className="grid grid-cols-3 gap-2 text-xs">
        <div className="rounded-md bg-panelSoft p-3">
          <div className="text-mist">Profit</div>
          <div className="mt-1 text-lg font-semibold text-slate-100">
            {result ? `${result.profit_percent.toFixed(2)}%` : "-"}
          </div>
        </div>
        <div className="rounded-md bg-panelSoft p-3">
          <div className="text-mist">Win Rate</div>
          <div className="mt-1 text-lg font-semibold text-slate-100">
            {result ? percent(result.win_rate) : "-"}
          </div>
        </div>
        <div className="rounded-md bg-panelSoft p-3">
          <div className="text-mist">Trades</div>
          <div className="mt-1 text-lg font-semibold text-slate-100">{result?.total_trades ?? "-"}</div>
        </div>
      </div>

      <div className="mt-4 h-48 rounded-lg border border-line bg-ink/40 p-3">
        {result?.equity_curve?.length ? (
          <Bar
            data={chartData}
            options={{
              responsive: true,
              maintainAspectRatio: false,
              plugins: { legend: { display: false } },
              scales: {
                x: { ticks: { display: false }, grid: { display: false } },
                y: { ticks: { color: "#7f8da3", callback: (value) => formatPrice(value) }, grid: { color: "rgba(148,163,184,0.08)" } }
              }
            }}
          />
        ) : (
          <div className="flex h-full items-center justify-center text-sm text-mist">No backtest run loaded.</div>
        )}
      </div>

      <div className="mt-3 max-h-40 overflow-y-auto rounded-lg border border-line scrollbar-thin">
        {(result?.trade_history || []).slice(-8).reverse().map((trade, index) => (
          <div key={`${trade.entry_time}-${index}`} className="grid grid-cols-4 gap-2 border-b border-line px-3 py-2 text-xs last:border-b-0">
            <span className={trade.side === "buy" ? "text-emerald-300" : "text-rose-300"}>{trade.side.toUpperCase()}</span>
            <span className="text-mist">{formatPrice(trade.entry)}</span>
            <span className="text-mist">{formatPrice(trade.exit)}</span>
            <span className={trade.pnl >= 0 ? "text-emerald-300" : "text-rose-300"}>{formatPrice(trade.pnl)}</span>
          </div>
        ))}
      </div>
    </section>
  );
}
