const API_URL = import.meta.env.VITE_API_URL || "http://127.0.0.1:8000";
const WS_URL = import.meta.env.VITE_WS_URL || "ws://127.0.0.1:8000";

async function request(path, options = {}) {
  const response = await fetch(`${API_URL}${path}`, {
    headers: {
      "Content-Type": "application/json",
      ...(options.headers || {})
    },
    ...options
  });
  if (!response.ok) {
    const payload = await response.json().catch(() => ({}));
    throw new Error(payload.detail || `Request failed: ${response.status}`);
  }
  return response.json();
}

export const api = {
  analyze: (body) =>
    request("/api/analyze", {
      method: "POST",
      body: JSON.stringify(body)
    }),
  chat: (body) =>
    request("/api/chat", {
      method: "POST",
      body: JSON.stringify(body)
    }),
  backtest: (body) =>
    request("/api/backtest", {
      method: "POST",
      body: JSON.stringify(body)
    }),
  signals: (limit = 10) => request(`/api/signals?limit=${limit}`),
  refreshSignals: () =>
    request("/api/signals/refresh", {
      method: "POST"
    }),
  metrics: () => request("/api/metrics"),
  paperOrders: () => request("/api/paper/orders"),
  createPaperOrder: (body) =>
    request("/api/paper/orders", {
      method: "POST",
      body: JSON.stringify(body)
    }),
  wsUrl: (path) => `${WS_URL}${path}`
};
