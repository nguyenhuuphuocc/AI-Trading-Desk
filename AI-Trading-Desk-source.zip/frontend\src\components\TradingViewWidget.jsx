function tradingViewSymbol(symbol, assetType) {
  const clean = symbol.replace("/", "").toUpperCase();
  if (assetType === "crypto") return `BINANCE:${clean}`;
  if (symbol.toUpperCase() === "SPY" || symbol.toUpperCase() === "QQQ") return `AMEX:${symbol.toUpperCase()}`;
  return `NASDAQ:${symbol.toUpperCase()}`;
}

export default function TradingViewWidget({ symbol, assetType, timeframe }) {
  const tvSymbol = encodeURIComponent(tradingViewSymbol(symbol, assetType));
  const interval = timeframe.toLowerCase().includes("d") ? "D" : timeframe.replace("m", "");
  const src = `https://www.tradingview.com/widgetembed/?symbol=${tvSymbol}&interval=${interval}&theme=dark&style=1&timezone=Etc%2FUTC&withdateranges=1&hide_side_toolbar=0&allow_symbol_change=1&save_image=0&studies=%5B%5D&locale=en`;

  return (
    <div className="hidden h-[430px] overflow-hidden rounded-lg border border-line bg-panel md:block">
      <iframe
        key={`${symbol}-${assetType}-${timeframe}`}
        title={`${symbol} TradingView chart`}
        src={src}
        className="h-full w-full border-0"
        allowFullScreen
      />
    </div>
  );
}
