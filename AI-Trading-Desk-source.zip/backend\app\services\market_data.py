from __future__ import annotations

import asyncio
from datetime import datetime, timezone
from typing import Dict, List, Optional

import ccxt
import httpx
import pandas as pd

from backend.app.config import get_settings
from strategies.indicators import normalize_ohlcv


CRYPTO_TIMEFRAMES = {
    "1m": "1m",
    "5m": "5m",
    "15m": "15m",
    "1h": "1h",
    "1H": "1h",
    "4h": "4h",
    "4H": "4h",
    "1d": "1d",
    "1D": "1d",
    "daily": "1d",
}

YAHOO_INTERVALS = {
    "1m": ("1m", "7d"),
    "5m": ("5m", "60d"),
    "15m": ("15m", "60d"),
    "1h": ("60m", "180d"),
    "1H": ("60m", "180d"),
    "4h": ("60m", "180d"),
    "4H": ("60m", "180d"),
    "1d": ("1d", "5y"),
    "1D": ("1d", "5y"),
    "daily": ("1d", "5y"),
}

ALPACA_TIMEFRAMES = {
    "1m": "1Min",
    "5m": "5Min",
    "15m": "15Min",
    "1h": "1Hour",
    "1H": "1Hour",
    "4h": "4Hour",
    "4H": "4Hour",
    "1d": "1Day",
    "1D": "1Day",
    "daily": "1Day",
}


class MarketDataService:
    def __init__(self) -> None:
        self.settings = get_settings()
        self._exchange_cache: Dict[str, ccxt.Exchange] = {}

    async def fetch_ohlcv(
        self,
        symbol: str,
        asset_type: str = "crypto",
        timeframe: str = "15m",
        limit: int = 240,
        exchange: Optional[str] = None,
    ) -> pd.DataFrame:
        asset_type = asset_type.lower()
        if asset_type == "crypto":
            return await self.fetch_crypto_ohlcv(symbol, timeframe, limit, exchange)
        if asset_type == "stock":
            if self.settings.alpaca_api_key and self.settings.alpaca_api_secret:
                try:
                    return await self.fetch_alpaca_bars(symbol, timeframe, limit)
                except Exception:
                    return await self.fetch_yahoo_bars(symbol, timeframe, limit)
            return await self.fetch_yahoo_bars(symbol, timeframe, limit)
        if asset_type == "forex":
            yahoo_symbol = symbol if "=X" in symbol.upper() else f"{symbol.replace('/', '')}=X"
            return await self.fetch_yahoo_bars(yahoo_symbol, timeframe, limit)
        raise ValueError(f"Unsupported asset type: {asset_type}")

    async def fetch_crypto_ohlcv(
        self, symbol: str, timeframe: str = "15m", limit: int = 240, exchange: Optional[str] = None
    ) -> pd.DataFrame:
        exchange_name = (exchange or self.settings.default_exchange).lower()
        timeframe = CRYPTO_TIMEFRAMES.get(timeframe, timeframe.lower())
        market_symbol = self._normalize_crypto_symbol(symbol)

        exchange_order = [exchange_name] if exchange else [exchange_name, "kraken", "binanceus", "binance"]
        last_error: Optional[Exception] = None
        rows: List = []
        for candidate in dict.fromkeys(exchange_order):
            def _fetch() -> List:
                client = self._exchange(candidate)
                return client.fetch_ohlcv(market_symbol, timeframe=timeframe, limit=limit)

            try:
                rows = await asyncio.to_thread(_fetch)
                break
            except Exception as exc:
                last_error = exc
                rows = []
        if not rows and last_error:
            raise last_error
        return normalize_ohlcv(rows)

    async def fetch_yahoo_bars(self, symbol: str, timeframe: str = "15m", limit: int = 240) -> pd.DataFrame:
        interval, range_value = YAHOO_INTERVALS.get(timeframe, ("15m", "60d"))
        params = {
            "interval": interval,
            "range": range_value,
            "includePrePost": "true",
            "events": "div,splits",
        }
        url = f"https://query2.finance.yahoo.com/v8/finance/chart/{symbol.upper()}"
        headers = {"User-Agent": "Mozilla/5.0 (compatible; AITradingDesk/1.0)"}
        async with httpx.AsyncClient(timeout=20.0) as client:
            response = await client.get(url, params=params, headers=headers)
            response.raise_for_status()
            payload = response.json()

        result = payload.get("chart", {}).get("result", [])
        if not result:
            raise ValueError(f"No Yahoo Finance data returned for {symbol}")

        chart = result[0]
        timestamps = chart.get("timestamp") or []
        quote = (chart.get("indicators", {}).get("quote") or [{}])[0]
        rows = []
        for index, ts in enumerate(timestamps):
            try:
                rows.append(
                    [
                        ts,
                        quote["open"][index],
                        quote["high"][index],
                        quote["low"][index],
                        quote["close"][index],
                        quote["volume"][index] or 0,
                    ]
                )
            except (KeyError, IndexError):
                continue

        df = normalize_ohlcv(rows)
        if timeframe.lower() in {"4h", "4H"} and not df.empty:
            df = self._resample(df, "4H")
        return df.tail(limit).reset_index(drop=True)

    async def fetch_alpaca_bars(self, symbol: str, timeframe: str = "15m", limit: int = 240) -> pd.DataFrame:
        url = f"{self.settings.alpaca_data_base_url}/v2/stocks/{symbol.upper()}/bars"
        params = {
            "timeframe": ALPACA_TIMEFRAMES.get(timeframe, "15Min"),
            "limit": limit,
            "adjustment": "raw",
            "feed": "iex",
            "sort": "asc",
        }
        headers = {
            "APCA-API-KEY-ID": self.settings.alpaca_api_key,
            "APCA-API-SECRET-KEY": self.settings.alpaca_api_secret,
        }
        async with httpx.AsyncClient(timeout=20.0) as client:
            response = await client.get(url, params=params, headers=headers)
            response.raise_for_status()
            payload = response.json()

        rows = [
            [bar["t"], bar["o"], bar["h"], bar["l"], bar["c"], bar.get("v", 0)]
            for bar in payload.get("bars", [])
        ]
        return normalize_ohlcv(rows)

    async def quote(self, symbol: str, asset_type: str = "crypto", exchange: Optional[str] = None) -> Dict:
        df = await self.fetch_ohlcv(symbol, asset_type=asset_type, timeframe="1m", limit=3, exchange=exchange)
        if df.empty:
            raise ValueError(f"No quote available for {symbol}")
        row = df.iloc[-1]
        return {
            "symbol": symbol.upper(),
            "asset_type": asset_type,
            "price": round(float(row["close"]), 6),
            "timestamp": row["timestamp"].isoformat(),
        }

    def _exchange(self, exchange_name: str) -> ccxt.Exchange:
        if exchange_name not in self._exchange_cache:
            exchange_cls = getattr(ccxt, exchange_name, None)
            if exchange_cls is None:
                raise ValueError(f"Unsupported ccxt exchange: {exchange_name}")
            self._exchange_cache[exchange_name] = exchange_cls({"enableRateLimit": True})
        return self._exchange_cache[exchange_name]

    def _normalize_crypto_symbol(self, symbol: str) -> str:
        if "/" in symbol:
            return symbol.upper()
        if symbol.upper().endswith("USDT"):
            return f"{symbol[:-4].upper()}/USDT"
        if symbol.upper().endswith("USD"):
            return f"{symbol[:-3].upper()}/USD"
        return f"{symbol.upper()}/USDT"

    def _resample(self, df: pd.DataFrame, rule: str) -> pd.DataFrame:
        indexed = df.set_index("timestamp")
        out = indexed.resample(rule).agg(
            {"open": "first", "high": "max", "low": "min", "close": "last", "volume": "sum"}
        )
        out = out.dropna().reset_index()
        # Pandas keeps the timezone; normalize_ohlcv gives us a clean schema.
        return normalize_ohlcv(out)


def now_utc_iso() -> str:
    return datetime.now(timezone.utc).isoformat()
