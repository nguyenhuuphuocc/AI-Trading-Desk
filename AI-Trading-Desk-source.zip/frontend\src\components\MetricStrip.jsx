import { Activity, CircleDollarSign, Gauge, ShieldCheck, TrendingUp } from "lucide-react";
import { formatPrice, percent } from "../lib/format";

export default function MetricStrip({ analysis, metrics }) {
  const latestBacktest = metrics?.latest_backtest;
  const items = [
    {
      icon: <Gauge size={17} />,
      label: "Confidence",
      value: analysis ? percent(analysis.confidence) : "-"
    },
    {
      icon: <ShieldCheck size={17} />,
      label: "Risk",
      value: analysis ? `${(analysis.risk.risk_percent * 100).toFixed(1)}%` : "-"
    },
    {
      icon: <TrendingUp size={17} />,
      label: "Win Rate",
      value: latestBacktest ? percent(latestBacktest.win_rate) : percent(metrics?.paper_trading?.win_rate)
    },
    {
      icon: <CircleDollarSign size={17} />,
      label: "P/L",
      value: metrics?.paper_trading ? formatPrice(metrics.paper_trading.realized_pnl) : "-"
    },
    {
      icon: <Activity size={17} />,
      label: "Drawdown",
      value: latestBacktest ? percent(latestBacktest.max_drawdown) : "-"
    }
  ];

  return (
    <div className="grid grid-cols-2 gap-3 md:grid-cols-5">
      {items.map((item) => (
        <div key={item.label} className="rounded-lg border border-line bg-panel px-4 py-3 shadow-glow">
          <div className="flex items-center gap-2 text-xs text-mist">
            <span className="text-teal-300">{item.icon}</span>
            <span>{item.label}</span>
          </div>
          <div className="mt-2 truncate text-xl font-semibold text-slate-50">{item.value}</div>
        </div>
      ))}
    </div>
  );
}
