from __future__ import annotations

from dataclasses import dataclass

from backend.app.config import get_settings


@dataclass
class PositionSize:
    quantity: float
    risk_amount: float
    risk_per_unit: float
    notional: float


class RiskManager:
    def __init__(self) -> None:
        self.settings = get_settings()

    def position_size(
        self,
        entry: float,
        stop_loss: float,
        account_equity: float | None = None,
        risk_percent: float | None = None,
    ) -> PositionSize:
        equity = account_equity or self.settings.account_equity
        risk = risk_percent or self.settings.max_risk_per_trade
        risk_amount = equity * risk
        risk_per_unit = abs(entry - stop_loss)
        quantity = risk_amount / risk_per_unit if risk_per_unit > 0 else 0.0
        return PositionSize(
            quantity=round(quantity, 6),
            risk_amount=round(risk_amount, 2),
            risk_per_unit=round(risk_per_unit, 6),
            notional=round(quantity * entry, 2),
        )

    def daily_loss_limit_reached(self, realized_pnl_today: float, account_equity: float | None = None) -> bool:
        equity = account_equity or self.settings.account_equity
        return realized_pnl_today <= -(equity * self.settings.max_daily_loss)

    def validate_rr(self, entry: float, stop_loss: float, take_profit: float, side: str) -> float:
        if side == "buy":
            risk = entry - stop_loss
            reward = take_profit - entry
        else:
            risk = stop_loss - entry
            reward = entry - take_profit
        if risk <= 0:
            return 0.0
        return round(reward / risk, 2)
