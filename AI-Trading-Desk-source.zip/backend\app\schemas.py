from datetime import datetime
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field


class AnalyzeRequest(BaseModel):
    symbol: str = Field("BTC/USDT", description="Crypto pair or stock ticker")
    asset_type: str = Field("crypto", regex="^(crypto|stock|forex)$")
    timeframe: str = Field("15m")
    exchange: Optional[str] = None
    limit: int = Field(240, ge=80, le=1500)
    account_equity: Optional[float] = Field(None, gt=0)
    risk_percent: Optional[float] = Field(None, gt=0, le=0.05)


class ChatRequest(BaseModel):
    message: str
    symbol: Optional[str] = None
    asset_type: Optional[str] = None
    timeframe: str = "15m"
    user_id: str = "demo"


class BacktestRequest(BaseModel):
    symbol: str = "BTC/USDT"
    asset_type: str = Field("crypto", regex="^(crypto|stock|forex)$")
    timeframe: str = "1h"
    exchange: Optional[str] = None
    limit: int = Field(500, ge=150, le=2000)
    account_equity: float = Field(10000, gt=0)
    risk_percent: float = Field(0.01, gt=0, le=0.05)


class PaperOrderRequest(BaseModel):
    symbol: str
    side: str = Field(..., regex="^(buy|sell)$")
    quantity: float = Field(..., gt=0)
    entry: float = Field(..., gt=0)
    stop_loss: float = Field(..., gt=0)
    take_profit: float = Field(..., gt=0)
    payload: Dict[str, Any] = {}


class SignalResponse(BaseModel):
    symbol: str
    asset_type: str
    timeframe: str
    action: str
    confidence: float
    entry: float
    stop_loss: float
    take_profit: float
    risk_reward: float
    position_size: float
    rationale: str
    indicators: Dict[str, Any]
    ict: Dict[str, Any]
    risk: Dict[str, Any]
    candles: List[Dict[str, Any]]
    timestamp: datetime


class ChatResponse(BaseModel):
    answer: str
    analysis: Optional[Dict[str, Any]] = None
    suggested_actions: List[str] = []


class BacktestResponse(BaseModel):
    symbol: str
    asset_type: str
    timeframe: str
    profit_percent: float
    win_rate: float
    max_drawdown: float
    total_trades: int
    trade_history: List[Dict[str, Any]]
    equity_curve: List[Dict[str, Any]]
    summary: Dict[str, Any]
