from __future__ import annotations

from datetime import datetime
from typing import Dict, List

from sqlalchemy.orm import Session

from backend.app.db_models import PaperOrder


class PaperTradingService:
    def create_order(self, db: Session, payload: Dict) -> Dict:
        order = PaperOrder(**payload)
        db.add(order)
        db.commit()
        db.refresh(order)
        return self._serialize(order)

    def list_orders(self, db: Session, limit: int = 50) -> List[Dict]:
        rows = db.query(PaperOrder).order_by(PaperOrder.created_at.desc()).limit(limit).all()
        return [self._serialize(row) for row in rows]

    def close_order(self, db: Session, order_id: int, exit_price: float) -> Dict:
        order = db.query(PaperOrder).filter(PaperOrder.id == order_id).first()
        if order is None:
            raise ValueError("Paper order not found")

        if order.side == "buy":
            order.pnl = (exit_price - order.entry) * order.quantity
        else:
            order.pnl = (order.entry - exit_price) * order.quantity
        order.status = "closed"
        order.closed_at = datetime.utcnow()
        db.commit()
        db.refresh(order)
        return self._serialize(order)

    def _serialize(self, order: PaperOrder) -> Dict:
        return {
            "id": order.id,
            "symbol": order.symbol,
            "side": order.side,
            "quantity": order.quantity,
            "entry": order.entry,
            "stop_loss": order.stop_loss,
            "take_profit": order.take_profit,
            "status": order.status,
            "pnl": order.pnl,
            "payload": order.payload or {},
            "created_at": order.created_at.isoformat(),
            "closed_at": order.closed_at.isoformat() if order.closed_at else None,
        }
