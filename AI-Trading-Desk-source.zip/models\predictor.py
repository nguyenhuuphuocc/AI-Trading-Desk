from __future__ import annotations

from typing import Dict

import numpy as np
import pandas as pd
from sklearn.linear_model import Ridge
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler

from strategies.indicators import add_indicators


class PricePredictor:
    """Lightweight ML predictor used as an optional ensemble hint.

    This is intentionally compact and retrains on demand. For production, swap this
    interface with a persisted LSTM/transformer model and a real feature store.
    """

    def __init__(self) -> None:
        self.model = Pipeline([("scale", StandardScaler()), ("ridge", Ridge(alpha=1.0))])

    def predict_next_close(self, raw_df: pd.DataFrame) -> Dict[str, float]:
        df = add_indicators(raw_df).dropna()
        if len(df) < 80:
            last_close = float(raw_df.iloc[-1]["close"])
            return {"prediction": last_close, "expected_change_percent": 0.0, "confidence": 0.0}

        features = df[["close", "volume_ratio", "rsi_14", "macd_hist", "atr_14", "ema_20", "ema_50"]].copy()
        target = df["close"].shift(-1)
        features = features.iloc[:-1]
        target = target.iloc[:-1]
        self.model.fit(features, target)
        prediction = float(self.model.predict(df[features.columns].tail(1))[0])
        last_close = float(df.iloc[-1]["close"])
        change = (prediction - last_close) / last_close * 100
        residuals = target - self.model.predict(features)
        confidence = max(0.0, min(0.75, 1 - (np.std(residuals) / max(last_close, 1e-9))))
        return {
            "prediction": round(prediction, 6),
            "expected_change_percent": round(float(change), 3),
            "confidence": round(float(confidence), 3),
        }
