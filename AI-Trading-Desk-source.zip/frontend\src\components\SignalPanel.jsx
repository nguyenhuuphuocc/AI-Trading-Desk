import { Bell, Crosshair, RefreshCw, Shield, TrendingDown, TrendingUp } from "lucide-react";
import { actionClass, formatPrice, percent } from "../lib/format";

export default function SignalPanel({ analysis, signals, loading, onRefresh }) {
  const visible = analysis ? [analysis, ...signals.filter((signal) => signal.symbol !== analysis.symbol)] : signals;

  return (
    <section className="rounded-lg border border-line bg-panel p-4 shadow-glow">
      <div className="mb-4 flex items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <Crosshair size={18} className="text-teal-300" />
          <h2 className="text-sm font-semibold uppercase tracking-wide text-slate-200">Signals</h2>
        </div>
        <button
          type="button"
          title="Refresh signals"
          onClick={onRefresh}
          className="inline-flex h-9 w-9 items-center justify-center rounded-md border border-line bg-panelSoft text-mist transition hover:border-teal-400 hover:text-teal-200"
        >
          <RefreshCw size={16} className={loading ? "animate-spin" : ""} />
        </button>
      </div>

      <div className="space-y-3">
        {visible.slice(0, 5).map((signal, index) => (
          <article key={`${signal.symbol}-${index}`} className="rounded-lg border border-line bg-ink/40 p-3">
            <div className="flex items-start justify-between gap-3">
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-base font-semibold text-white">{signal.symbol}</span>
                  <span className={`rounded-md border px-2 py-0.5 text-xs font-semibold ${actionClass(signal.action)}`}>
                    {signal.action.toUpperCase()}
                  </span>
                </div>
                <p className="mt-1 line-clamp-2 text-xs leading-5 text-mist">{signal.rationale}</p>
              </div>
              {signal.action === "sell" ? (
                <TrendingDown className="mt-1 text-rose-300" size={18} />
              ) : (
                <TrendingUp className="mt-1 text-emerald-300" size={18} />
              )}
            </div>

            <div className="mt-3 grid grid-cols-3 gap-2 text-xs">
              <div className="rounded-md bg-panelSoft p-2">
                <div className="text-mist">Entry</div>
                <div className="mt-1 font-semibold text-slate-100">{formatPrice(signal.entry)}</div>
              </div>
              <div className="rounded-md bg-panelSoft p-2">
                <div className="text-mist">Stop</div>
                <div className="mt-1 font-semibold text-rose-200">{formatPrice(signal.stop_loss)}</div>
              </div>
              <div className="rounded-md bg-panelSoft p-2">
                <div className="text-mist">Target</div>
                <div className="mt-1 font-semibold text-emerald-200">{formatPrice(signal.take_profit)}</div>
              </div>
            </div>

            <div className="mt-3 flex items-center justify-between text-xs text-mist">
              <span className="inline-flex items-center gap-1">
                <Shield size={13} /> RR {signal.risk_reward}:1
              </span>
              <span>{percent(signal.confidence)}</span>
            </div>
          </article>
        ))}

        {!visible.length && (
          <div className="rounded-lg border border-dashed border-line p-5 text-center text-sm text-mist">
            No stored signals yet.
          </div>
        )}
      </div>

      <button
        type="button"
        title="Send alert"
        className="mt-4 inline-flex w-full items-center justify-center gap-2 rounded-md border border-line bg-panelSoft px-3 py-2 text-sm text-slate-200 transition hover:border-amber-300 hover:text-amber-100"
      >
        <Bell size={16} /> Alert
      </button>
    </section>
  );
}
