from __future__ import annotations

from typing import Any, Dict, List

import pandas as pd

from strategies.engine import StrategyEngine
from strategies.indicators import normalize_ohlcv


class Backtester:
    """Simple single-position backtester for the strategy engine."""

    def __init__(self) -> None:
        self.engine = StrategyEngine()

    def run(
        self,
        raw_df: pd.DataFrame,
        symbol: str,
        asset_type: str,
        timeframe: str,
        account_equity: float,
        risk_percent: float,
    ) -> Dict[str, Any]:
        df = normalize_ohlcv(raw_df)
        if len(df) < 150:
            raise ValueError("At least 150 candles are required for backtesting.")

        equity = account_equity
        peak_equity = equity
        max_drawdown = 0.0
        trades: List[Dict[str, Any]] = []
        equity_curve: List[Dict[str, Any]] = []
        index = 90

        while index < len(df) - 2:
            sample = df.iloc[: index + 1]
            try:
                signal = self.engine.analyze(
                    sample,
                    symbol=symbol,
                    asset_type=asset_type,
                    timeframe=timeframe,
                    account_equity=equity,
                    risk_percent=risk_percent,
                )
            except ValueError:
                index += 1
                continue

            if signal["action"] == "hold" or signal["confidence"] < 0.58:
                equity_curve.append({"time": df.iloc[index]["timestamp"].isoformat(), "equity": round(equity, 2)})
                index += 1
                continue

            trade = self._simulate_trade(df, index + 1, signal, equity, risk_percent)
            equity += trade["pnl"]
            peak_equity = max(peak_equity, equity)
            drawdown = (peak_equity - equity) / peak_equity if peak_equity else 0.0
            max_drawdown = max(max_drawdown, drawdown)
            trade["ending_equity"] = round(equity, 2)
            trades.append(trade)
            equity_curve.append({"time": trade["exit_time"], "equity": round(equity, 2)})
            index = trade["exit_index"] + 1

        wins = sum(1 for trade in trades if trade["pnl"] > 0)
        win_rate = wins / len(trades) if trades else 0.0
        profit_percent = ((equity - account_equity) / account_equity) * 100

        return {
            "symbol": symbol.upper(),
            "asset_type": asset_type,
            "timeframe": timeframe,
            "profit_percent": round(float(profit_percent), 2),
            "win_rate": round(float(win_rate), 3),
            "max_drawdown": round(float(max_drawdown), 3),
            "total_trades": len(trades),
            "trade_history": trades,
            "equity_curve": equity_curve,
            "summary": {
                "starting_equity": round(float(account_equity), 2),
                "ending_equity": round(float(equity), 2),
                "wins": wins,
                "losses": len(trades) - wins,
                "average_pnl": round(float(sum(t["pnl"] for t in trades) / len(trades)), 2)
                if trades
                else 0.0,
            },
        }

    def _simulate_trade(
        self,
        df: pd.DataFrame,
        start_index: int,
        signal: Dict[str, Any],
        equity: float,
        risk_percent: float,
        max_holding_bars: int = 60,
    ) -> Dict[str, Any]:
        side = signal["action"]
        entry = float(signal["entry"])
        stop = float(signal["stop_loss"])
        target = float(signal["take_profit"])
        size = float(signal["position_size"])
        risk_amount = equity * risk_percent
        exit_price = float(df.iloc[start_index]["close"])
        exit_index = min(start_index, len(df) - 1)
        exit_reason = "timeout"

        for index in range(start_index, min(len(df), start_index + max_holding_bars)):
            row = df.iloc[index]
            exit_index = index
            if side == "buy":
                if float(row["low"]) <= stop:
                    exit_price = stop
                    exit_reason = "stop_loss"
                    break
                if float(row["high"]) >= target:
                    exit_price = target
                    exit_reason = "take_profit"
                    break
            else:
                if float(row["high"]) >= stop:
                    exit_price = stop
                    exit_reason = "stop_loss"
                    break
                if float(row["low"]) <= target:
                    exit_price = target
                    exit_reason = "take_profit"
                    break
            exit_price = float(row["close"])

        if side == "buy":
            pnl = (exit_price - entry) * size
        else:
            pnl = (entry - exit_price) * size

        # Cap pathological gaps in this simplified simulator.
        pnl = max(min(pnl, risk_amount * signal["risk_reward"] * 1.5), -risk_amount * 1.5)

        return {
            "symbol": signal["symbol"],
            "side": side,
            "entry_time": df.iloc[start_index]["timestamp"].isoformat(),
            "exit_time": df.iloc[exit_index]["timestamp"].isoformat(),
            "entry": round(entry, 6),
            "exit": round(float(exit_price), 6),
            "stop_loss": round(stop, 6),
            "take_profit": round(target, 6),
            "quantity": round(size, 6),
            "pnl": round(float(pnl), 2),
            "return_percent": round(float(pnl / equity * 100), 3) if equity else 0.0,
            "confidence": signal["confidence"],
            "exit_reason": exit_reason,
            "exit_index": exit_index,
        }
