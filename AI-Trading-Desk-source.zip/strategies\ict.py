from __future__ import annotations

from typing import Any, Dict, List

import pandas as pd


def _safe_float(value, default: float = 0.0) -> float:
    if pd.isna(value):
        return default
    return float(value)


def _swing_points(df: pd.DataFrame, lookback: int = 3) -> Dict[str, List[Dict[str, Any]]]:
    highs: List[Dict[str, Any]] = []
    lows: List[Dict[str, Any]] = []
    if len(df) < lookback * 2 + 1:
        return {"highs": highs, "lows": lows}

    for index in range(lookback, len(df) - lookback):
        window = df.iloc[index - lookback : index + lookback + 1]
        current = df.iloc[index]
        if current["high"] >= window["high"].max():
            highs.append(
                {
                    "index": index,
                    "timestamp": current["timestamp"].isoformat(),
                    "price": round(float(current["high"]), 6),
                }
            )
        if current["low"] <= window["low"].min():
            lows.append(
                {
                    "index": index,
                    "timestamp": current["timestamp"].isoformat(),
                    "price": round(float(current["low"]), 6),
                }
            )
    return {"highs": highs, "lows": lows}


def detect_bos(df: pd.DataFrame, swing_lookback: int = 3, break_window: int = 40) -> Dict[str, Any]:
    swings = _swing_points(df.tail(break_window + 20).reset_index(drop=True), swing_lookback)
    if df.empty or not swings["highs"] or not swings["lows"]:
        return {"direction": "none", "level": None, "strength": 0.0}

    latest_close = float(df.iloc[-1]["close"])
    recent_high = max(swings["highs"][-5:], key=lambda item: item["price"])
    recent_low = min(swings["lows"][-5:], key=lambda item: item["price"])
    atr_value = _safe_float(df.iloc[-1].get("atr_14"), latest_close * 0.01)
    buffer = max(atr_value * 0.05, latest_close * 0.0005)

    if latest_close > recent_high["price"] + buffer:
        strength = min(1.0, (latest_close - recent_high["price"]) / max(atr_value, 1e-9))
        return {"direction": "bullish", "level": recent_high["price"], "strength": round(strength, 3)}
    if latest_close < recent_low["price"] - buffer:
        strength = min(1.0, (recent_low["price"] - latest_close) / max(atr_value, 1e-9))
        return {"direction": "bearish", "level": recent_low["price"], "strength": round(strength, 3)}

    return {"direction": "none", "level": None, "strength": 0.0}


def detect_fvg(df: pd.DataFrame, lookback: int = 80) -> Dict[str, Any]:
    gaps: List[Dict[str, Any]] = []
    subset = df.tail(lookback).reset_index(drop=True)
    for index in range(2, len(subset)):
        first = subset.iloc[index - 2]
        middle = subset.iloc[index - 1]
        third = subset.iloc[index]

        if third["low"] > first["high"]:
            size = float(third["low"] - first["high"])
            gaps.append(
                {
                    "direction": "bullish",
                    "start": round(float(first["high"]), 6),
                    "end": round(float(third["low"]), 6),
                    "midpoint": round(float(first["high"] + size / 2), 6),
                    "timestamp": third["timestamp"].isoformat(),
                    "body_pct": round(float(middle.get("body_pct", 0.0)), 6),
                }
            )
        elif third["high"] < first["low"]:
            size = float(first["low"] - third["high"])
            gaps.append(
                {
                    "direction": "bearish",
                    "start": round(float(third["high"]), 6),
                    "end": round(float(first["low"]), 6),
                    "midpoint": round(float(third["high"] + size / 2), 6),
                    "timestamp": third["timestamp"].isoformat(),
                    "body_pct": round(float(middle.get("body_pct", 0.0)), 6),
                }
            )

    latest = gaps[-1] if gaps else None
    return {"latest": latest, "active": gaps[-5:], "count": len(gaps)}


def liquidity_zones(df: pd.DataFrame, lookback: int = 120) -> Dict[str, Any]:
    subset = df.tail(lookback).reset_index(drop=True)
    swings = _swing_points(subset, 3)
    current_price = float(df.iloc[-1]["close"]) if not df.empty else 0.0

    buy_side = sorted(swings["highs"], key=lambda item: abs(item["price"] - current_price))[:5]
    sell_side = sorted(swings["lows"], key=lambda item: abs(item["price"] - current_price))[:5]

    return {
        "buy_side": buy_side,
        "sell_side": sell_side,
        "nearest_buy_liquidity": buy_side[0]["price"] if buy_side else None,
        "nearest_sell_liquidity": sell_side[0]["price"] if sell_side else None,
    }


def supply_demand_zones(df: pd.DataFrame, lookback: int = 120) -> Dict[str, Any]:
    subset = df.tail(lookback).copy()
    if subset.empty:
        return {"demand": [], "supply": []}

    volume_threshold = subset["volume_ratio"].fillna(1.0).quantile(0.75)
    impulse = subset[
        (subset["volume_ratio"].fillna(1.0) >= volume_threshold)
        & (subset["body_pct"].fillna(0.0) >= subset["body_pct"].fillna(0.0).quantile(0.60))
    ]

    demand = []
    supply = []
    for _, row in impulse.tail(20).iterrows():
        zone = {
            "low": round(float(row["low"]), 6),
            "high": round(float(row["high"]), 6),
            "timestamp": row["timestamp"].isoformat(),
            "volume_ratio": round(float(row.get("volume_ratio", 1.0)), 3),
        }
        if row["close"] >= row["open"]:
            demand.append(zone)
        else:
            supply.append(zone)

    return {"demand": demand[-5:], "supply": supply[-5:]}


def analyze_ict(df: pd.DataFrame) -> Dict[str, Any]:
    return {
        "bos": detect_bos(df),
        "fvg": detect_fvg(df),
        "liquidity": liquidity_zones(df),
        "zones": supply_demand_zones(df),
    }
