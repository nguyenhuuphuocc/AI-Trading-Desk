from __future__ import annotations

from typing import Dict

import numpy as np
import pandas as pd
from pandas.api.types import is_datetime64_any_dtype


OHLCV_COLUMNS = ["timestamp", "open", "high", "low", "close", "volume"]


def normalize_ohlcv(data) -> pd.DataFrame:
    """Return a sorted OHLCV DataFrame with numeric columns and UTC timestamps."""
    df = pd.DataFrame(data)
    if df.empty:
        return pd.DataFrame(columns=OHLCV_COLUMNS)

    if list(df.columns[:6]) != OHLCV_COLUMNS and len(df.columns) >= 6:
        df = df.iloc[:, :6]
        df.columns = OHLCV_COLUMNS

    for column in ["open", "high", "low", "close", "volume"]:
        df[column] = pd.to_numeric(df[column], errors="coerce")

    if not is_datetime64_any_dtype(df["timestamp"]):
        numeric_ts = pd.to_numeric(df["timestamp"], errors="coerce")
        if numeric_ts.notna().mean() > 0.8:
            median = numeric_ts.dropna().median()
            unit = "ms" if median > 10_000_000_000 else "s"
            df["timestamp"] = pd.to_datetime(numeric_ts, unit=unit, errors="coerce", utc=True)
        else:
            df["timestamp"] = pd.to_datetime(df["timestamp"], errors="coerce", utc=True)

    df = df.dropna(subset=OHLCV_COLUMNS).sort_values("timestamp").reset_index(drop=True)
    return df


def ema(series: pd.Series, span: int) -> pd.Series:
    return series.ewm(span=span, adjust=False, min_periods=max(2, span // 2)).mean()


def rsi(close: pd.Series, period: int = 14) -> pd.Series:
    delta = close.diff()
    gains = delta.clip(lower=0)
    losses = -delta.clip(upper=0)
    avg_gain = gains.ewm(alpha=1 / period, adjust=False, min_periods=period).mean()
    avg_loss = losses.ewm(alpha=1 / period, adjust=False, min_periods=period).mean()
    rs = avg_gain / avg_loss.replace(0, np.nan)
    output = 100 - (100 / (1 + rs))
    output = output.mask((avg_loss == 0) & (avg_gain > 0), 100)
    output = output.mask((avg_loss == 0) & (avg_gain == 0), 50)
    return output


def macd(close: pd.Series) -> Dict[str, pd.Series]:
    fast = ema(close, 12)
    slow = ema(close, 26)
    macd_line = fast - slow
    signal = ema(macd_line, 9)
    histogram = macd_line - signal
    return {"macd": macd_line, "macd_signal": signal, "macd_hist": histogram}


def atr(df: pd.DataFrame, period: int = 14) -> pd.Series:
    prev_close = df["close"].shift(1)
    true_range = pd.concat(
        [
            df["high"] - df["low"],
            (df["high"] - prev_close).abs(),
            (df["low"] - prev_close).abs(),
        ],
        axis=1,
    ).max(axis=1)
    return true_range.ewm(alpha=1 / period, adjust=False, min_periods=period).mean()


def add_indicators(df: pd.DataFrame) -> pd.DataFrame:
    df = normalize_ohlcv(df).copy()
    if df.empty:
        return df

    df["ema_20"] = ema(df["close"], 20)
    df["ema_50"] = ema(df["close"], 50)
    df["ema_200"] = ema(df["close"], 200)
    df["rsi_14"] = rsi(df["close"], 14)
    macd_values = macd(df["close"])
    for name, series in macd_values.items():
        df[name] = series
    df["atr_14"] = atr(df, 14)
    df["volume_sma_20"] = df["volume"].rolling(20, min_periods=5).mean()
    df["volume_ratio"] = df["volume"] / df["volume_sma_20"].replace(0, np.nan)
    df["body_pct"] = (df["close"] - df["open"]).abs() / df["close"].replace(0, np.nan)
    return df


def latest_indicator_snapshot(df: pd.DataFrame) -> Dict[str, float]:
    if df.empty:
        return {}

    row = df.iloc[-1]
    keys = [
        "close",
        "ema_20",
        "ema_50",
        "ema_200",
        "rsi_14",
        "macd",
        "macd_signal",
        "macd_hist",
        "atr_14",
        "volume_ratio",
    ]
    snapshot = {}
    for key in keys:
        value = row.get(key)
        if pd.notna(value):
            snapshot[key] = round(float(value), 6)
    return snapshot
