import {
  CategoryScale,
  Chart as ChartJS,
  Filler,
  Legend,
  LinearScale,
  LineElement,
  PointElement,
  Tooltip
} from "chart.js";
import { Line } from "react-chartjs-2";
import { formatPrice } from "../lib/format";

ChartJS.register(CategoryScale, LinearScale, PointElement, LineElement, Tooltip, Legend, Filler);

export default function PriceChart({ candles = [] }) {
  const sliced = candles.slice(-90);
  const data = {
    labels: sliced.map((candle) =>
      new Date(candle.time).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
    ),
    datasets: [
      {
        label: "Close",
        data: sliced.map((candle) => candle.close),
        borderColor: "#2dd4bf",
        backgroundColor: "rgba(45, 212, 191, 0.12)",
        fill: true,
        borderWidth: 2,
        pointRadius: 0,
        tension: 0.28
      }
    ]
  };

  const options = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: { display: false },
      tooltip: {
        callbacks: {
          label: (context) => formatPrice(context.parsed.y)
        }
      }
    },
    scales: {
      x: {
        grid: { color: "rgba(148, 163, 184, 0.08)" },
        ticks: { color: "#7f8da3", maxTicksLimit: 6 }
      },
      y: {
        position: "right",
        grid: { color: "rgba(148, 163, 184, 0.08)" },
        ticks: {
          color: "#7f8da3",
          callback: (value) => formatPrice(value)
        }
      }
    }
  };

  return (
    <div className="h-48 rounded-lg border border-line bg-panelSoft p-3">
      <Line data={data} options={options} />
    </div>
  );
}
