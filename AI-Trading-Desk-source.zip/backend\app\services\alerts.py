from __future__ import annotations

import smtplib
from email.message import EmailMessage
from typing import Dict

import httpx

from backend.app.config import get_settings


class AlertService:
    def __init__(self) -> None:
        self.settings = get_settings()

    async def send_signal_alert(self, signal: Dict) -> Dict[str, bool]:
        message = (
            f"{signal['symbol']} {signal['action'].upper()} {signal['timeframe']}\n"
            f"Entry {signal['entry']} | SL {signal['stop_loss']} | TP {signal['take_profit']}\n"
            f"Confidence {signal['confidence'] * 100:.0f}%"
        )
        telegram = await self._send_telegram(message)
        email = self._send_email("Trading signal", message)
        return {"telegram": telegram, "email": email}

    async def _send_telegram(self, text: str) -> bool:
        if not self.settings.telegram_bot_token or not self.settings.telegram_chat_id:
            return False
        url = f"https://api.telegram.org/bot{self.settings.telegram_bot_token}/sendMessage"
        async with httpx.AsyncClient(timeout=10.0) as client:
            response = await client.post(url, json={"chat_id": self.settings.telegram_chat_id, "text": text})
            return response.status_code < 300

    def _send_email(self, subject: str, body: str) -> bool:
        if not all(
            [
                self.settings.smtp_host,
                self.settings.alert_email_from,
                self.settings.alert_email_to,
                self.settings.smtp_username,
                self.settings.smtp_password,
            ]
        ):
            return False

        email = EmailMessage()
        email["From"] = self.settings.alert_email_from
        email["To"] = self.settings.alert_email_to
        email["Subject"] = subject
        email.set_content(body)
        with smtplib.SMTP(self.settings.smtp_host, self.settings.smtp_port) as smtp:
            smtp.starttls()
            smtp.login(self.settings.smtp_username, self.settings.smtp_password)
            smtp.send_message(email)
        return True
