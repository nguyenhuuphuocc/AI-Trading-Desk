from backend.app.services.risk import RiskManager


def test_position_size_uses_fixed_fractional_risk():
    manager = RiskManager()
    result = manager.position_size(entry=100, stop_loss=95, account_equity=10_000, risk_percent=0.01)
    assert result.risk_amount == 100
    assert result.risk_per_unit == 5
    assert result.quantity == 20
    assert result.notional == 2000


def test_rr_for_long_trade():
    manager = RiskManager()
    assert manager.validate_rr(entry=100, stop_loss=95, take_profit=110, side="buy") == 2
