import { Bot, Loader2, Send, UserRound } from "lucide-react";
import { useState } from "react";

export default function ChatPanel({ messages, loading, onSubmit }) {
  const [draft, setDraft] = useState("Analyze BTC/USDT and give me a high probability trade");

  function submit(event) {
    event.preventDefault();
    if (!draft.trim()) return;
    onSubmit(draft.trim());
    setDraft("");
  }

  return (
    <section className="flex h-[470px] flex-col rounded-lg border border-line bg-panel shadow-glow md:h-[620px]">
      <div className="flex items-center gap-2 border-b border-line px-4 py-3">
        <Bot size={18} className="text-teal-300" />
        <h2 className="text-sm font-semibold uppercase tracking-wide text-slate-200">Trading Chat</h2>
      </div>

      <div className="scrollbar-thin flex-1 space-y-4 overflow-y-auto p-4">
        {messages.map((message, index) => (
          <div key={`${message.role}-${index}`} className="flex gap-3">
            <div className="mt-1 flex h-8 w-8 shrink-0 items-center justify-center rounded-md border border-line bg-panelSoft text-teal-200">
              {message.role === "user" ? <UserRound size={16} /> : <Bot size={16} />}
            </div>
            <div className="min-w-0 flex-1">
              <div className="text-xs uppercase tracking-wide text-mist">{message.role}</div>
              <div className="mt-1 whitespace-pre-line rounded-lg bg-ink/45 p-3 text-sm leading-6 text-slate-100">
                {message.content}
              </div>
            </div>
          </div>
        ))}
        {loading && (
          <div className="flex items-center gap-2 text-sm text-mist">
            <Loader2 size={16} className="animate-spin text-teal-300" />
            Thinking through the setup
          </div>
        )}
      </div>

      <form onSubmit={submit} className="border-t border-line p-3">
        <div className="flex gap-2">
          <textarea
            value={draft}
            onChange={(event) => setDraft(event.target.value)}
            onKeyDown={(event) => {
              if (event.key === "Enter" && !event.shiftKey) submit(event);
            }}
            rows={2}
            className="min-h-[48px] flex-1 resize-none rounded-md border border-line bg-ink px-3 py-2 text-sm text-slate-100 outline-none transition placeholder:text-slate-500 focus:border-teal-400"
            placeholder="Ask for BTC, ETH, NASDAQ, AAPL..."
          />
          <button
            type="submit"
            title="Send"
            disabled={loading}
            className="inline-flex w-12 items-center justify-center rounded-md bg-teal-400 text-ink transition hover:bg-teal-300 disabled:cursor-not-allowed disabled:opacity-50"
          >
            {loading ? <Loader2 size={18} className="animate-spin" /> : <Send size={18} />}
          </button>
        </div>
      </form>
    </section>
  );
}
