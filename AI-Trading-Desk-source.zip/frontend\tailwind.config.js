/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,jsx}"],
  theme: {
    extend: {
      fontFamily: {
        sans: ["Inter", "ui-sans-serif", "system-ui", "sans-serif"]
      },
      colors: {
        ink: "#090b10",
        panel: "#111722",
        panelSoft: "#151e2c",
        line: "#273142",
        mist: "#aab6ca",
        ember: "#f59e0b"
      },
      boxShadow: {
        glow: "0 0 0 1px rgba(45, 212, 191, 0.14), 0 16px 50px rgba(0, 0, 0, 0.35)"
      }
    }
  },
  plugins: []
};
