from __future__ import annotations

import math
from datetime import date, datetime
from typing import Any, Dict, List, Optional

from fastapi.encoders import jsonable_encoder
from sqlalchemy.orm import Session

from backend.app.config import get_settings
from backend.app.db_models import TradeSignal
from backend.app.services.market_data import MarketDataService
from models import PricePredictor
from strategies import StrategyEngine


class SignalService:
    def __init__(self) -> None:
        self.settings = get_settings()
        self.market_data = MarketDataService()
        self.engine = StrategyEngine()
        self.predictor = PricePredictor()

    async def analyze(
        self,
        symbol: str,
        asset_type: str = "crypto",
        timeframe: str = "15m",
        limit: int = 240,
        exchange: Optional[str] = None,
        account_equity: Optional[float] = None,
        risk_percent: Optional[float] = None,
        db: Optional[Session] = None,
    ) -> Dict[str, Any]:
        df = await self.market_data.fetch_ohlcv(
            symbol=symbol,
            asset_type=asset_type,
            timeframe=timeframe,
            limit=limit,
            exchange=exchange,
        )
        signal = self.engine.analyze(
            df,
            symbol=symbol,
            asset_type=asset_type,
            timeframe=timeframe,
            account_equity=account_equity,
            risk_percent=risk_percent,
        )
        signal["prediction"] = self.predictor.predict_next_close(df)
        signal = self._clean_json(signal)
        if db is not None:
            self.persist_signal(db, signal)
        return signal

    async def current_signals(self, db: Session, limit: int = 10) -> List[Dict[str, Any]]:
        rows = (
            db.query(TradeSignal)
            .order_by(TradeSignal.created_at.desc())
            .limit(limit)
            .all()
        )
        return [self._row_to_dict(row) for row in rows]

    async def refresh_watchlist(self, db: Session) -> List[Dict[str, Any]]:
        refreshed: List[Dict[str, Any]] = []
        for symbol in self.settings.default_watchlist:
            asset_type = "crypto" if "/" in symbol or symbol.endswith("USDT") else "stock"
            normalized = symbol if asset_type == "crypto" else symbol.replace("^", "")
            try:
                signal = await self.analyze(
                    symbol=normalized,
                    asset_type=asset_type,
                    timeframe="15m" if asset_type == "crypto" else "1h",
                    limit=240,
                    db=db,
                )
                refreshed.append(signal)
            except Exception as exc:
                refreshed.append({"symbol": symbol, "error": str(exc)})
        return refreshed

    def persist_signal(self, db: Session, signal: Dict[str, Any]) -> TradeSignal:
        row = TradeSignal(
            symbol=signal["symbol"],
            asset_type=signal["asset_type"],
            timeframe=signal["timeframe"],
            action=signal["action"],
            confidence=signal["confidence"],
            entry=signal["entry"],
            stop_loss=signal["stop_loss"],
            take_profit=signal["take_profit"],
            risk_reward=signal["risk_reward"],
            position_size=signal["position_size"],
            rationale=signal["rationale"],
            payload=jsonable_encoder(signal),
        )
        db.add(row)
        db.commit()
        db.refresh(row)
        return row

    def _row_to_dict(self, row: TradeSignal) -> Dict[str, Any]:
        payload = row.payload or {}
        payload.setdefault("id", row.id)
        payload.setdefault("created_at", row.created_at.isoformat())
        return self._clean_json(payload)

    def _clean_json(self, value: Any) -> Any:
        if isinstance(value, dict):
            return {key: self._clean_json(item) for key, item in value.items()}
        if isinstance(value, list):
            return [self._clean_json(item) for item in value]
        if isinstance(value, float):
            return value if math.isfinite(value) else None
        if isinstance(value, (datetime, date)):
            return value.isoformat()
        return value
