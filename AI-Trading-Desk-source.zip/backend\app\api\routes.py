from __future__ import annotations

import asyncio
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query, WebSocket, WebSocketDisconnect
from fastapi.encoders import jsonable_encoder
from sqlalchemy import func
from sqlalchemy.orm import Session

from backend.app.config import get_settings
from backend.app.database import SessionLocal, get_db
from backend.app.db_models import BacktestRun, PaperOrder, TradeSignal
from backend.app.schemas import (
    AnalyzeRequest,
    BacktestRequest,
    ChatRequest,
    PaperOrderRequest,
)
from backend.app.services.alerts import AlertService
from backend.app.services.chatbot import ChatbotService
from backend.app.services.market_data import MarketDataService
from backend.app.services.paper_trading import PaperTradingService
from backend.app.services.signal_service import SignalService
from strategies import Backtester


router = APIRouter()
settings = get_settings()
signals = SignalService()
chatbot = ChatbotService()
backtester = Backtester()
market_data = MarketDataService()
paper = PaperTradingService()
alerts = AlertService()


@router.get("/health")
async def health():
    return {
        "status": "ok",
        "app": settings.app_name,
        "environment": settings.environment,
        "live_websocket_enabled": settings.live_websocket_enabled,
    }


@router.post("/chat")
async def chat(request: ChatRequest, db: Session = Depends(get_db)):
    try:
        return await chatbot.chat(
            message=request.message,
            db=db,
            user_id=request.user_id,
            symbol=request.symbol,
            asset_type=request.asset_type,
            timeframe=request.timeframe,
        )
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@router.post("/analyze")
async def analyze(request: AnalyzeRequest, db: Session = Depends(get_db)):
    try:
        return await signals.analyze(
            symbol=request.symbol,
            asset_type=request.asset_type,
            timeframe=request.timeframe,
            limit=request.limit,
            exchange=request.exchange,
            account_equity=request.account_equity,
            risk_percent=request.risk_percent,
            db=db,
        )
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@router.get("/signals")
async def current_signals(limit: int = Query(10, ge=1, le=100), db: Session = Depends(get_db)):
    return await signals.current_signals(db, limit=limit)


@router.post("/signals/refresh")
async def refresh_signals(db: Session = Depends(get_db)):
    return await signals.refresh_watchlist(db)


@router.post("/signals/alert")
async def alert_latest_signal(db: Session = Depends(get_db)):
    row = db.query(TradeSignal).order_by(TradeSignal.created_at.desc()).first()
    if row is None:
        raise HTTPException(status_code=404, detail="No signals available")
    return await alerts.send_signal_alert(row.payload)


@router.post("/backtest")
async def run_backtest(request: BacktestRequest, db: Session = Depends(get_db)):
    try:
        df = await market_data.fetch_ohlcv(
            symbol=request.symbol,
            asset_type=request.asset_type,
            timeframe=request.timeframe,
            limit=request.limit,
            exchange=request.exchange,
        )
        result = backtester.run(
            df,
            symbol=request.symbol,
            asset_type=request.asset_type,
            timeframe=request.timeframe,
            account_equity=request.account_equity,
            risk_percent=request.risk_percent,
        )
        row = BacktestRun(
            symbol=result["symbol"],
            asset_type=result["asset_type"],
            timeframe=result["timeframe"],
            strategy_name="ICT + RSI/MACD/EMA",
            profit_percent=result["profit_percent"],
            win_rate=result["win_rate"],
            max_drawdown=result["max_drawdown"],
            total_trades=result["total_trades"],
            payload=jsonable_encoder(result),
        )
        db.add(row)
        db.commit()
        return result
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@router.get("/metrics")
async def performance_metrics(db: Session = Depends(get_db)):
    latest_backtest = db.query(BacktestRun).order_by(BacktestRun.created_at.desc()).first()
    open_orders = db.query(func.count(PaperOrder.id)).filter(PaperOrder.status == "open").scalar() or 0
    closed_orders = db.query(PaperOrder).filter(PaperOrder.status == "closed").all()
    realized_pnl = sum(order.pnl or 0 for order in closed_orders)
    wins = sum(1 for order in closed_orders if (order.pnl or 0) > 0)
    win_rate = wins / len(closed_orders) if closed_orders else 0.0

    return {
        "paper_trading": {
            "open_orders": open_orders,
            "closed_orders": len(closed_orders),
            "realized_pnl": round(float(realized_pnl), 2),
            "win_rate": round(float(win_rate), 3),
        },
        "latest_backtest": latest_backtest.payload if latest_backtest else None,
        "signals_stored": db.query(func.count(TradeSignal.id)).scalar() or 0,
    }


@router.post("/paper/orders")
async def create_paper_order(request: PaperOrderRequest, db: Session = Depends(get_db)):
    try:
        return paper.create_order(db, request.dict())
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@router.get("/paper/orders")
async def list_paper_orders(limit: int = Query(50, ge=1, le=200), db: Session = Depends(get_db)):
    return paper.list_orders(db, limit=limit)


@router.post("/paper/orders/{order_id}/close")
async def close_paper_order(order_id: int, exit_price: float = Query(..., gt=0), db: Session = Depends(get_db)):
    try:
        return paper.close_order(db, order_id=order_id, exit_price=exit_price)
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


@router.websocket("/ws/signals")
async def signals_socket(websocket: WebSocket):
    await websocket.accept()
    try:
        while True:
            db = SessionLocal()
            try:
                payload = await signals.current_signals(db, limit=10)
            finally:
                db.close()
            await websocket.send_json(jsonable_encoder(payload))
            await asyncio.sleep(settings.signal_refresh_seconds)
    except WebSocketDisconnect:
        return


@router.websocket("/ws/market")
async def market_socket(
    websocket: WebSocket,
    symbol: str = Query("BTC/USDT"),
    asset_type: str = Query("crypto"),
    timeframe: str = Query("1m"),
    exchange: Optional[str] = Query(None),
):
    await websocket.accept()
    try:
        while True:
            quote = await market_data.quote(symbol, asset_type=asset_type, exchange=exchange)
            await websocket.send_json(jsonable_encoder(quote))
            await asyncio.sleep(settings.signal_refresh_seconds)
    except WebSocketDisconnect:
        return
