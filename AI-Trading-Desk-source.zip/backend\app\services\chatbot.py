from __future__ import annotations

import json
import re
from typing import Any, Dict, Optional, Tuple

from fastapi.encoders import jsonable_encoder
from openai import OpenAI
from sqlalchemy.orm import Session

from backend.app.config import get_settings
from backend.app.db_models import ChatMessage
from backend.app.services.signal_service import SignalService


SYMBOL_PATTERN = re.compile(r"\b([A-Z]{2,6}(?:/[A-Z]{2,6}|USDT|USD)?|\^?[A-Z]{3,6})\b")
CRYPTO_BASES = {"BTC", "ETH", "SOL", "XRP", "BNB", "DOGE", "ADA", "AVAX", "LINK", "DOT", "MATIC"}


class ChatbotService:
    def __init__(self) -> None:
        self.settings = get_settings()
        self.signals = SignalService()

    async def chat(
        self,
        message: str,
        db: Session,
        user_id: str = "demo",
        symbol: Optional[str] = None,
        asset_type: Optional[str] = None,
        timeframe: str = "15m",
    ) -> Dict[str, Any]:
        parsed_symbol, parsed_asset = self._parse_symbol(message)
        symbol = symbol or parsed_symbol or "BTC/USDT"
        asset_type = asset_type or parsed_asset or ("crypto" if "/" in symbol or symbol.endswith("USDT") else "stock")

        self._save_message(db, user_id, "user", message, {"symbol": symbol, "asset_type": asset_type})
        analysis = await self.signals.analyze(
            symbol=symbol,
            asset_type=asset_type,
            timeframe=timeframe,
            limit=260,
            db=db,
        )
        answer = await self._llm_answer(message, analysis)
        self._save_message(db, user_id, "assistant", answer, {"analysis": analysis})
        return {
            "answer": answer,
            "analysis": analysis,
            "suggested_actions": [
                f"Run a {timeframe} backtest on {analysis['symbol']}",
                "Set a paper trade alert",
                "Compare the setup on 1H and 4H",
            ],
        }

    async def _llm_answer(self, message: str, analysis: Dict[str, Any]) -> str:
        if not self.settings.openai_api_key:
            return self._deterministic_answer(analysis)

        client = OpenAI(api_key=self.settings.openai_api_key)
        system = (
            "You are a disciplined trading analyst. Explain the setup in simple language, "
            "avoid certainty, include risk controls, and never present the signal as financial advice."
        )
        context = {
            "signal": {
                key: analysis[key]
                for key in [
                    "symbol",
                    "asset_type",
                    "timeframe",
                    "action",
                    "confidence",
                    "entry",
                    "stop_loss",
                    "take_profit",
                    "risk_reward",
                    "position_size",
                    "rationale",
                    "indicators",
                    "ict",
                    "risk",
                    "prediction",
                ]
                if key in analysis
            }
        }
        try:
            response = client.responses.create(
                model=self.settings.openai_model,
                input=[
                    {"role": "system", "content": system},
                    {
                        "role": "user",
                        "content": (
                            f"User question: {message}\n\n"
                            f"Market/strategy context JSON:\n{json.dumps(context, default=str)}\n\n"
                            "Respond with: bias, entry plan, stop/target, risk notes, and why the setup can fail."
                        ),
                    },
                ],
                temperature=0.25,
            )
            return response.output_text.strip()
        except Exception:
            return self._deterministic_answer(analysis)

    def _deterministic_answer(self, analysis: Dict[str, Any]) -> str:
        action = analysis["action"].upper()
        confidence = int(analysis["confidence"] * 100)
        if action == "HOLD":
            return (
                f"I would stand aside on {analysis['symbol']} for now. The model confidence is only "
                f"{confidence}%, and the indicator/ICT stack is not clean enough for a 1:2 setup. "
                f"{analysis['rationale']}"
            )

        return (
            f"{analysis['symbol']} has a candidate {action} setup on the {analysis['timeframe']} chart.\n\n"
            f"Entry: {analysis['entry']}\n"
            f"Stop loss: {analysis['stop_loss']}\n"
            f"Take profit: {analysis['take_profit']}\n"
            f"Risk/reward: {analysis['risk_reward']}:1\n"
            f"Suggested position size: {analysis['position_size']} units "
            f"for {analysis['risk']['risk_percent'] * 100:.1f}% account risk.\n"
            f"Confidence: {confidence}%\n\n"
            f"Why: {analysis['rationale']}\n\n"
            "Invalidation: skip or reduce size if price rejects the entry area, volume dries up, "
            "or a higher-timeframe level is directly against the trade."
        )

    def _parse_symbol(self, message: str) -> Tuple[Optional[str], Optional[str]]:
        upper = message.upper()
        if "NASDAQ" in upper or "NDX" in upper:
            return "QQQ", "stock"
        if "S&P" in upper or "SPY" in upper:
            return "SPY", "stock"

        matches = SYMBOL_PATTERN.findall(upper)
        ignored = {"WHAT", "GIVE", "HIGH", "TODAY", "TRADE", "ANALYZE", "SELL", "BUY", "LONG", "SHORT"}
        for match in matches:
            if match in ignored:
                continue
            if "/" in match:
                return match, "crypto"
            if match in CRYPTO_BASES:
                return f"{match}/USDT", "crypto"
            if match.endswith("USDT") or match.endswith("USD") and match[:-3] in {"BTC", "ETH", "SOL", "XRP"}:
                base = match[:-4] if match.endswith("USDT") else match[:-3]
                return f"{base}/USDT", "crypto"
            return match, "stock"
        return None, None

    def _save_message(self, db: Session, user_id: str, role: str, message: str, context: Dict[str, Any]) -> None:
        db.add(ChatMessage(user_id=user_id, role=role, message=message, context=jsonable_encoder(context)))
        db.commit()
