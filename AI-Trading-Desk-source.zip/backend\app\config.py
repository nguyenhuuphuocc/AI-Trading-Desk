import os
from functools import lru_cache
from pathlib import Path
from typing import List

from dotenv import load_dotenv


ROOT_DIR = Path(__file__).resolve().parents[2]
load_dotenv(ROOT_DIR / ".env")
load_dotenv(Path.cwd() / ".env")


def _get_bool(name: str, default: bool) -> bool:
    value = os.getenv(name)
    if value is None:
        return default
    return value.lower() in {"1", "true", "yes", "on"}


def _get_float(name: str, default: float) -> float:
    try:
        return float(os.getenv(name, default))
    except (TypeError, ValueError):
        return default


def _get_int(name: str, default: int) -> int:
    try:
        return int(os.getenv(name, default))
    except (TypeError, ValueError):
        return default


class Settings:
    app_name: str = os.getenv("APP_NAME", "AI Trading Chatbot")
    environment: str = os.getenv("ENVIRONMENT", "development")
    api_prefix: str = os.getenv("API_PREFIX", "/api")
    cors_origins: List[str] = [
        item.strip()
        for item in os.getenv(
            "CORS_ORIGINS",
            "http://localhost:5173,http://127.0.0.1:5173,http://localhost:8080",
        ).split(",")
        if item.strip()
    ]

    database_url: str = os.getenv("DATABASE_URL", "sqlite:///./trading_bot.db")

    openai_api_key: str = os.getenv("OPENAI_API_KEY", "")
    openai_model: str = os.getenv("OPENAI_MODEL", "gpt-5.4-mini")

    alpaca_api_key: str = os.getenv("ALPACA_API_KEY", "")
    alpaca_api_secret: str = os.getenv("ALPACA_API_SECRET", "")
    alpaca_data_base_url: str = os.getenv(
        "ALPACA_DATA_BASE_URL", "https://data.alpaca.markets"
    )

    default_exchange: str = os.getenv("DEFAULT_CRYPTO_EXCHANGE", "kraken")
    default_watchlist: List[str] = [
        item.strip().upper()
        for item in os.getenv(
            "DEFAULT_WATCHLIST", "BTC/USDT,ETH/USDT,NASDAQ,AAPL,TSLA"
        ).split(",")
        if item.strip()
    ]

    account_equity: float = _get_float("ACCOUNT_EQUITY", 10000.0)
    max_risk_per_trade: float = _get_float("MAX_RISK_PER_TRADE", 0.01)
    max_daily_loss: float = _get_float("MAX_DAILY_LOSS", 0.03)
    minimum_rr: float = _get_float("MINIMUM_RR", 2.0)
    signal_refresh_seconds: int = _get_int("SIGNAL_REFRESH_SECONDS", 20)
    live_websocket_enabled: bool = _get_bool("LIVE_WEBSOCKET_ENABLED", True)

    telegram_bot_token: str = os.getenv("TELEGRAM_BOT_TOKEN", "")
    telegram_chat_id: str = os.getenv("TELEGRAM_CHAT_ID", "")
    alert_email_from: str = os.getenv("ALERT_EMAIL_FROM", "")
    alert_email_to: str = os.getenv("ALERT_EMAIL_TO", "")
    smtp_host: str = os.getenv("SMTP_HOST", "")
    smtp_port: int = _get_int("SMTP_PORT", 587)
    smtp_username: str = os.getenv("SMTP_USERNAME", "")
    smtp_password: str = os.getenv("SMTP_PASSWORD", "")


@lru_cache
def get_settings() -> Settings:
    return Settings()
